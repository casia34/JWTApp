﻿namespace TokenSicurezza.Modells
{
    public class TokenApiModel
    {
        public string? accessToken { get; set; }
        public string? RefreshToken { get; set; }
    }
}
